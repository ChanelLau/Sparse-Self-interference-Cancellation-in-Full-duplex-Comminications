function [chan C0 Zn] = CS_IOLS_kapa(mtx_A,b,epsilon,mPower,t)

% DOMP Algorithm.
%
%
% July 2023.
%
% Info: chaneaaa@163.com
% -------------------------------------------------------------------------
% $Revision: 1.0$  $Date: 2023/08/07$
% $Revision: 1.1$  $Date: xxxx/xx/xx$
% -------------------------------------------------------------------------
% License to use and modify this code is granted freely without warranty to
% all, as long as the original authors are referenced and attributed as such.
% The original authors maintain the right to be solely associated with this
% work.
% -------------------------------------------------------------------------
% ?2023
% Chang Liu,  
% Department of Electronics Engineering
% (DGUT) -- Dongguan University of Tech.

%% CS_IOLS algorithm

[b_rows,b_columns] = size(b);

if b_rows < b_columns
   b = b';                       %b should be a column vector
end

[M,N] = size(mtx_A);             %measurement matrix demenaion: M*N 

k = t;                           % preselected sparse level

%% initialization 

r(:,1) = b;                      

Cn = [];                         

An = [];                         

Zn = [];                         

Fn = 1:size(mtx_A,2);            

norm_As = [];                    

%% Normalization
abs_colmn = sqrt(sum(abs(mtx_A).^2)); 

abs_matrix = repmat(abs_colmn,M,1);

norm_A  = mtx_A./abs_matrix;
%disp(sum(norm_A.^2))
%% IOLS iterative solution

kapa = 2*epsilon*sqrt(mPower);

for ii = 2:k+1
    
    product = norm_A' * r(:,ii-1);        
    [val,index] = max(abs(product));
     
    Cn = [Cn index];
    Zn = [Zn product(index)];
    An = [An mtx_A(:,index)];
    norm_As = [norm_As norm_A(:,index)];

    r(:,ii) = r(:,ii-1) - product(index)*norm_A(:,index);

    if val  < kapa  
         break;
    end


    %% Gram-Schmidt orthogonalization

    Rn = setdiff(Fn,Cn);

    norm_Ar = norm_A(:,Rn);

    Cr = zeros(N-length(Cn),1);

    Cr = norm_Ar.'*conj(norm_A(:,index));

    norm_Ar = norm_Ar - kron(Cr.',norm_A(:,index));
    %% Normalization

    for kk=1:N-length(Cn)
        norm_Ar(:,kk)=norm_Ar(:,kk)/norm(norm_Ar(:,kk));
    end

    norm_A(:,Rn) = norm_Ar;

    ii = ii +1;

end

x_recovery = zeros(N,1);

xk = BackwardSub_ols(An,norm_As,Zn);   % Backward substitution solution

x_recovery(Cn) = xk;

chan = x_recovery;

C0 = Cn;
