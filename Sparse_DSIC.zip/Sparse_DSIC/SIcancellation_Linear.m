function [y_can, y_resid] = SIcancellation_Linear(x,y,chan, chanLen) 

% SIcancellation_Linear.
%
%
% Dec 2022.
%
% Info: chaneaaa@163.com
% -------------------------------------------------------------------------
% $Revision: 1.0$  $Date: 2023/01/10$
% $Revision: 1.1$  $Date: xxxx/xx/xx$
% -------------------------------------------------------------------------
% License to use and modify this code is granted freely without warranty to
% all, as long as the original authors are referenced and attributed as such.
% The original authors maintain the right to be solely associated with this
% work.
% -------------------------------------------------------------------------
% ?2022
% Chang Liu,  
% Department of Electronics Engineering
% (DGUT) -- Dongguan University of Tech.

%chan = zeros(chanLen,1);

y_can = conv(x,chan);

y_can = y_can(1:length(x));

y_resid = y((chanLen+1):end) - y_can((chanLen+1):end);