% 
% DEMO on test_plotPSD
% test_plotPSD.
%
% This demo file implements the experimental test shown in:

% July 2023.
%
% Info: liuchang@dgut.edu.cn
% -------------------------------------------------------------------------
% $Revision: 1.0$  $Date: 2023/08/11$
% $Revision: 1.1$  $Date: xxxx/xx/xx$
% -------------------------------------------------------------------------
% License to use and modify this code is granted freely without warranty to
% all, as long as the original authors are referenced and attributed as such.
% The original authors maintain the right to be solely associated with this
% work.
% -------------------------------------------------------------------------
% ?2022
% Chang Liu,  
% Department of Electronics Engineering
% (DGUT) -- Dongguan University of Tech.
% -------------------------------------------------------------------------

clear; 
close all;
disp('test_plotPSD');
% -------------------------------------------------------------------------
%%  Data generation
params.samplingFreMHz = 20;
params.hSILen = 13;
params.nonorder = 7;
params.dataOffset = 14;
params.trainingRatio = 0.9;

[x, y, noise, nPower]= Load_data(params);
Numtraining = floor(length(x)*params.trainingRatio);
x_training = x(1:Numtraining);
y_training = y(1:Numtraining);
x_test = x((Numtraining+1):end);
y_test = y((Numtraining+1):end);

chanLen = params.hSILen;

alpha = 0;

t = 200;

epsilon = 3.12e-5;

type = 'NL';

%% Memory Polynominal Model generation

[mtx_A, b] = Polymodel_gen(x_training,y_training,params.hSILen, ...
                         params.nonorder);
%% test_CanLinear
hLin = SIestimation_Linear(x_training,y_training,chanLen,alpha);

[y_can_Lin, y_resid_Lin] = SIcancellation_Linear(x_test,y_test,hLin,chanLen);

%% test_CanPolyNonLinear 
hNonlin = SIestimation_Nonlinear(x,y,chanLen,params.nonorder,alpha); 
                                                               %LS algorithm
[y_can_Nonlin, y_resid_Nonlin] = SIcancellation_Nonlinear(x_test,y_test,hNonlin, ...
                    params.nonorder,chanLen);

%% test_CanOMPNonlinear
[h_OMP C_omp] = CS_OMP(mtx_A,b,t,epsilon,alpha);           %OMP algorithm

[y_can_OMP, y_resid_OMP] = SIcancellation_Nonlinear(x_test,y_test,h_OMP, ...
                         params.nonorder,chanLen);

%% test_CanIOLSNonlinear
[h_IOLS C_iols Zn] = CS_IOLS(mtx_A,b,epsilon,nPower,t);  %IOLS algorithm

[y_can_IOLS, y_resid_IOLS] = SIcancellation_Nonlinear(x_test,y_test,h_IOLS, ...
                        params.nonorder,chanLen);

%% Scaling by Mearured Noise Power
noisepower = 10*log10(mean(abs(noise).^2));

ScalingConst = 10^(-(nPower-noisepower)/10); 

noise = noise/sqrt(ScalingConst);

y_test = y_test/sqrt(ScalingConst);

y_resid_Lin = y_resid_Lin/sqrt(ScalingConst);

y_resid_Nonlin = y_resid_Nonlin/sqrt(ScalingConst);

y_resid_OMP = y_resid_OMP/sqrt(ScalingConst);

y_resid_IOLS = y_resid_IOLS/sqrt(ScalingConst);

y_can_Lin =  y_can_Lin/sqrt(ScalingConst);

y_can_Nonlin = y_can_Nonlin/sqrt(ScalingConst);

%%  Power Calculation

if type == 'NL'

   noisepower = 10*log10(mean(abs(noise).^2));

   yTestPower = 10*log10(mean(abs(y_test((chanLen+1):end)).^2));

   yTestLinCanPower = 10*log10(mean(abs(y_resid_Lin).^2)) ;  %residual power

   yTestNonLinCanPower = 10*log10(mean(abs(y_resid_Nonlin).^2));  %residual power

   yTestOmpCanPower = 10*log10(mean(abs(y_resid_OMP).^2)) ;  %residual power

   yTestIolsCanPower = 10*log10(mean(abs(y_resid_IOLS).^2)) ;  %residual power

else

   noisepower = 10*log10(mean(abs(noise).^2));

   yTestPower = 10*log10(mean(abs(y_test((chanLen+1):end)).^2));

   yTestLinCanPower = 10*log10(mean(abs(y_resid_Lin).^2)) ;     %residual power

   yTestNonLinCanPower = 10*log10(mean(abs ((y_resid_Lin/sqrt(yVar)- ...
                              y_can_Nonlin)*sqrt(yVar)).^2));

   yTestOmpCanPower = 10*log10(mean(abs(y_resid_OMP).^2)) ;  %residual power

   yTestIolsCanPower = 10*log10(mean(abs(y_resid_IOLS).^2)) ;  %residual power
end

  load(['C:\Users\dell\Desktop\Sparse_DSIC\\RVNN_data\y_CancLin.mat']);
  load(['C:\Users\dell\Desktop\Sparse_DSIC' ...
       '\RVNN_data\y_Noncan_cvnn.mat']);
  load(['C:\Users\dell\Desktop\Sparse_DSIC' ...
       '\RVNN_data\y_test.mat']);
  load(['C:\Users\dell\Desktop\Sparse_DSIC' ...
       '\RVNN_data\y_Noncan_NN0.mat']);
  load(['C:\Users\dell\Desktop\Sparse_DSIC' ...
       '\RVNN_data\yVar.mat']);


  yTestRvnnCanPower = 10*log10(mean(abs(((y_test-y_Canc)/sqrt(y_var)- ...
                                     y_Noncan_NN)*sqrt(y_var)).^2));

  yTestCvnnCanPower = 10*log10(mean(abs(((y_test-y_Canc)/sqrt(y_var)- ...
                                     y_Noncan_cvnn)*sqrt(y_var)).^2));
                               
%% Spectra Calculation

samplingFreqMHz = params.samplingFreMHz;

fftpoints = 4096;

scalingConst = samplingFreqMHz*1e6;

freqAxis = linspace(-samplingFreqMHz/2,samplingFreqMHz/2,fftpoints);

savgolWindow = 45;

savgaolDegree = 1;

if type == 'NL'

    noisefft = fftshift(fft(noise/sqrt(fftpoints*scalingConst),fftpoints));

    yTestFFT = fftshift(fft(y_test((chanLen+1):end)/...
    sqrt(fftpoints*scalingConst), fftpoints));

    yTestLinCanFFT = fftshift(fft(y_resid_Lin/sqrt(fftpoints*scalingConst)...
                     , fftpoints));

    yTestNonLinCanFFT = fftshift(fft(y_resid_Nonlin/sqrt(scalingConst*fftpoints) ...
                     , fftpoints));

    yTestOmpCanFFT = fftshift(fft(y_resid_OMP/sqrt(scalingConst*fftpoints) ...
                     , fftpoints));

    yTestIolsCanFFT = fftshift(fft(y_resid_IOLS/sqrt(fftpoints*scalingConst)...
                     , fftpoints));

else

    noisefft = fftshift(fft(noise/sqrt(fftpoints*scalingConst), fftpoints));

    yTestFFT = fftshift(fft(y_test((chanLen+1):end)/sqrt(fftpoints*scalingConst), fftpoints));

    yTestLinCanFFT = fftshift(fft(y_resid_Lin/sqrt(fftpoints*scalingConst),fftpoints));

    yTestNonLinCanFFT = ...
  fftshift(fft((y_resid_Lin/sqrt(yVar)-y_can_Nonlin)*sqrt(yVar/scalingConst/fftpoints), fftpoints));

    yTestOmpCanFFT = fftshift(fft(y_resid_OMP/sqrt(fftpoints*scalingConst) ...
                     , fftpoints));

    yTestIolsCanFFT = fftshift(fft(y_resid_IOLS/sqrt(fftpoints*scalingConst)...
                     , fftpoints));

end

   yTestRvnnCanFFT = ...
            fftshift(fft(((y_test.'-y_Canc.')/sqrt(y_var)-y_Noncan_NN.')* ...
            sqrt(y_var/scalingConst/fftpoints), fftpoints));  

   yTestCvnnCanFFT = ...
            fftshift(fft(((y_test.'-y_Canc.')/sqrt(y_var)-y_Noncan_cvnn.')* ...
            sqrt(y_var/scalingConst/fftpoints), fftpoints));  

  %% plot Spectra
  toPlotyTestFFT = ...
        10*log10(sgolayfilt(abs(yTestFFT).^2, savgaolDegree, savgolWindow));

  toPlotyTestLinCanFFT = ...
        10*log10(sgolayfilt(abs(yTestLinCanFFT).^2, savgaolDegree, savgolWindow));

  toPlotyTestNonLinCanFFT = ...
        10*log10(sgolayfilt(abs(yTestNonLinCanFFT).^2, savgaolDegree, savgolWindow));

  toPlotyTestOmpCanFFT = ...
        10*log10(sgolayfilt(abs(yTestOmpCanFFT).^2, savgaolDegree, savgolWindow));

  toPlotyTestIolsCanFFT = ...
        10*log10(sgolayfilt(abs(yTestIolsCanFFT).^2, savgaolDegree, savgolWindow));

  toPlotynoisefft = ...
        10*log10(sgolayfilt(abs(noisefft).^2, savgaolDegree, savgolWindow));

   toPlotyTestRvnnFFT = ...
        10*log10(sgolayfilt(abs(double(yTestRvnnCanFFT)).^2, savgaolDegree, savgolWindow));

   toPlotyTestCvnnFFT = ...
        10*log10(sgolayfilt(abs(double(yTestCvnnCanFFT)).^2, savgaolDegree, savgolWindow));


   figure(1);
   plot(freqAxis, toPlotyTestFFT,'b-', 'linewidth',2);
   hold on;
   plot(freqAxis, toPlotyTestLinCanFFT,'r-', 'linewidth',2);
   plot(freqAxis, toPlotyTestNonLinCanFFT,'m-', 'linewidth',2);
   plot(freqAxis, toPlotyTestOmpCanFFT,'g--', 'linewidth',2);
  %plot(freqAxis, toPlotyTestIolsCanFFT,'y--', 'linewidth',1.5);
   plot(freqAxis, toPlotyTestIolsCanFFT,'Color',[0.5 0.5 0.4], ...
                              'LineWidth',2,'LineStyle','--');
   plot(freqAxis, toPlotyTestRvnnFFT,'Color',[0.7 0.3 0.1], ...
                              'LineWidth',2,'LineStyle','--');
   plot(freqAxis, toPlotyTestCvnnFFT,'Color',[1 0.8 0], ...
                              'LineWidth',2,'LineStyle','--');
   plot(freqAxis, toPlotynoisefft,'k--', 'linewidth',2);
   grid on;
   legend('SI Signal(-42.7dBm)','Linear LS(-80.6dBm)','MP-based LS (-87.9dBm)',...
   'OMP(-87.7dBm)','IOLS(-87.7dBm)','RVNN(-87.4dBm)','CVNN(-87.8dBm)', ...
   'Noise Floor(-90.8dBm)', 'location', 'southwestoutside')
   xlabel('Frequency (MHZ)')
   ylabel('Power Spectral Density(dBm/Hz)')

 
