function [xo] = BackwardSub_ols(A,norm_A,Z) 

% BackwardSub_ols.
%
%
% July 2023.
%
% Info: liuchang@dgut.edu.cn
% -------------------------------------------------------------------------
% $Revision: 1.0$  $Date: 2023/08/07$
% $Revision: 1.1$  $Date: xxxx/xx/xx$
% -------------------------------------------------------------------------
% License to use and modify this code is granted freely without warranty to
% all, as long as the original authors are referenced and attributed as such.
% The original authors maintain the right to be solely associated with this
% work.
% -------------------------------------------------------------------------
% ?2023
% Chang Liu,  
% Department of Electronics Engineering
% (DGUT) -- Dongguan University of Tech.
%
% Z ------------   Coeffiecents or signals in orthogonal subspace
% norm_A -------   Normal orthogonal basis: matrix Q in QR factorization
% A ------------   Basis in original subspace

disp('BackwardSub_ols:');

k = size(A,2);

xk0 = zeros(k,1);       % original coeffiecents or signals

Rs = norm_A'*A;         %Upper triangular matrix computation 
                        %(QR factorization)

xk0(k) = Z(k)/Rs(k,k); 

for mm = k-1:-1:1 

    xk0(mm) = (Z(mm) - Rs(mm,((mm+1):end))*xk0((mm+1):end))/...
              Rs(mm,mm);
end

xo = xk0;

