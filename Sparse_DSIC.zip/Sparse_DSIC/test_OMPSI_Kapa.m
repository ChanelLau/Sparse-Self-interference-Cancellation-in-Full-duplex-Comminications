% 
% DEMO on test_IOLS_Nonlinear for different eta.
% test_IOLS_Nonlinear for different eta with unknown noise vairance.
%
% This demo file implements the experimental test shown in:

% July 2023.
%
% Info: liuchang@dgut.edu.cn
% -------------------------------------------------------------------------
% $Revision: 1.0$  $Date: 2023/08/09$
% $Revision: 1.1$  $Date: xxxx/xx/xx$
% -------------------------------------------------------------------------
% License to use and modify this code is granted freely without warranty to
% all, as long as the original authors are referenced and attributed as such.
% The original authors maintain the right to be solely associated with this
% work.
% -------------------------------------------------------------------------
% ?2022
% Chang Liu,  
% Department of Electronics Engineering
% (DGUT) -- Dongguan University of Tech.
% -------------------------------------------------------------------------

clear; 
close all;
disp('test_IOLS_Nonlinear for different eta with unknown noise vairance');
% -------------------------------------------------------------------------
%%  Data generation
params.samplingFreMHz = 20.48;
params.hSILen = 13;
params.nonorder = 7;
params.dataOffset = 14;
params.trainingRatio = 0.8;

[x, y, noise, nPower]= Load_data(params);
Numtraining = floor(length(x)*params.trainingRatio);
x_training = x(1:Numtraining);
y_training = y(1:Numtraining);
x_test = x((Numtraining+1):end);
y_test = y((Numtraining+1):end);

alpha = 0;                                           %regulerized parameter

mPower = mean(abs(noise.^2));

%% Memory Polynominal Model generation

[mtx_A, b] = Polymodel_gen(x_training,y_training,params.hSILen, ...
                         params.nonorder);

h_LS = SIestimation_Nonlinear(x,y,params.hSILen,params.nonorder,alpha); 
                                                              %LS algorithm
y_resid_train0 = b - mtx_A * h_LS;

SI_CanLS_train0 = 10*log10(mean(abs(b.^2)) ...
                    /mean(abs(y_resid_train0.^2))); 
                                                     %residual SI(training)

PrdBm_train0 = 10*log10(mean(abs(y_resid_train0.^2))) + 30; 
                                                  %residual power(training)

[y_can_test0, y_resid_test0] = SIcancellation_Nonlinear(x_test,y_test,h_LS, ...
                    params.nonorder,params.hSILen);

PydBm = 10*log10(mean(abs(y_test.^2))) + 30;   %testing residual power(dBm)

SI_CanLS_test0  = 10*log10(mean(abs(y_test((params.hSILen+1):end).^2)) ...
                             /mean(abs(y_resid_test0.^2)));    
                                        %SI suppression ratio(IOLS testing)

%% CS_IOLS_kapa algorithm training

Numeps = 20;

vec_eta = linspace(1,10.5,Numeps);

t = 200;             %preselected sparse level (larger than the true level)

vec_SIcan_train1 = [];

vec_SIcan_test1 = [];

vec_C_ols = [];

vec_PrdBm_train1 = [];

for i = 1:Numeps
    

    [h_IOLS C_iols Zn] = CS_IOLS_kapa(mtx_A,b,vec_eta(i),mPower,t);  
                                                       %IOLS_kapa algorithm 
    vec_C_ols = [vec_C_ols length(C_iols)];

    y_resid_train1 = b - mtx_A * h_IOLS;                %IOLS residual SI

    SI_CanIOLS_train1 = 10*log10(mean(abs(b.^2))/mean(abs(y_resid_train1.^2))); 
                                       %SI suppression ratio(IOLS training)

    PrdBm_train1 = 10*log10(mean(abs(y_resid_train1.^2))) + 30;

    vec_PrdBm_train1 = [vec_PrdBm_train1 PrdBm_train1];

    vec_SIcan_train1 = [vec_SIcan_train1 SI_CanIOLS_train1];

%% Testing stage

    [y_can1, y_resid1] = SIcancellation_Nonlinear(x_test,y_test,h_IOLS, ...
                        params.nonorder,params.hSILen);

    SI_CanIOLS_test1  = 10*log10(mean(abs(y_test((params.hSILen+1):end).^2)) ...
                             /mean(abs(y_resid1.^2))); 
                                       %SI suppression ratio(IOLS testing)
    vec_SIcan_test1 = [vec_SIcan_test1 SI_CanIOLS_test1];

end

vec_SIcan_train0 = zeros(1,length(vec_SIcan_train1));

vec_SIcan_test0 = zeros(1,length(vec_SIcan_test1));

vec_PrdBm_train0 = zeros(1,length(vec_PrdBm_train1));

vec_SIcan_train0(1:end) = SI_CanLS_train0;

vec_SIcan_test0(1:end) = SI_CanLS_test0;

vec_PrdBm_train0(1:end) = PrdBm_train0;

figure(1);
subplot(2,1,1)
plot(vec_eta, vec_SIcan_train0,'--xk', 'linewidth',1.5);
hold on;
plot(vec_eta, vec_SIcan_train1,'--bs', 'linewidth',1.5);
title('(a)')
xlim([1,10.5])
ylim([44.5,45.3])
legend('LS','IOLS')
xlabel('Tolerance for stopping criterion (\eta)')
ylabel('SI Cancellation(dB)')
subplot(2,1,2)
plot(vec_eta, vec_C_ols,'--bs', 'linewidth',1.5);
title('(b)')
xlim([1,10.5])
legend('IOLS')
xlabel('Tolerance for stopping criterion (\eta)')
ylabel('Estimated sparse level (K)')
