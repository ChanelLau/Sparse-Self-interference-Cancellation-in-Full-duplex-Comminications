% 
% DEMO on test_RuningTime
% test_RuningTime for the LS_OMP_IOLS.
%
% This demo file implements the experimental test shown in:

% July 2023.
%
% Info: liuchang@dgut.edu.cn
% -------------------------------------------------------------------------
% $Revision: 1.0$  $Date: 2023/11/15$
% $Revision: 1.1$  $Date: xxxx/xx/xx$
% -------------------------------------------------------------------------
% License to use and modify this code is granted freely without warranty to
% all, as long as the original authors are referenced and attributed as such.
% The original authors maintain the right to be solely associated with this
% work.
% -------------------------------------------------------------------------
% ?2022
% Chang Liu,  
% Department of Electronics Engineering
% (DGUT) -- Dongguan University of Tech.
% -------------------------------------------------------------------------
% -------------------------------------------------------------------------

clear; 
close all;
disp('test_RuningTime_LS_OMP_IOLS');
% -------------------------------------------------------------------------
%%  Data generation
params.samplingFreMHz = 20;
params.hSILen = 13;
params.nonorder = 7;
params.dataOffset = 14;
params.trainingRatio = 0.8;

[x, y, noise, nPower]= Load_data(params);
Numtraining = floor(length(x)*params.trainingRatio);
x_training = x(1:Numtraining);
y_training = y(1:Numtraining);
x_test = x((Numtraining+1):end);
y_test = y((Numtraining+1):end);

chanLen = params.hSILen;

alpha = 0;

t = 40;

epsilon = 3.2e-5;

vec_time0 =[];

vec_time1 =[];

vec_time2 =[];

nTime = 2;

%% Memory Polynominal Model generation
        
[mtx_A, b] = Polymodel_gen(x_training,y_training,params.hSILen, ...
                         params.nonorder);
for n = 1:nTime
%% test_CanPolyNonLinear 
    tic;

    hNonlin = SIestimation_Nonlinear(x,y,chanLen,params.nonorder,alpha); 
                                                              %LS algorithm

    [y_can_Nonlin, y_resid_Nonlin] = SIcancellation_Nonlinear(x_test,y_test,hNonlin, ...
                    params.nonorder,chanLen);

    times0 = toc;

    vec_time0 = [vec_time0 times0];
%% test_CanOMPNonlinear
    tic;

    [h_OMP C_omp] = CS_OMP(mtx_A,b,t,epsilon,alpha);             %OMP algorithm

    [y_can_OMP, y_resid_OMP] = SIcancellation_Nonlinear(x_test,y_test,h_OMP, ...
                           params.nonorder,chanLen);
    times1 = toc;

    vec_time1 = [vec_time1 times1];
%% test_CanIOLSNonlinear
    tic; 

    [h_IOLS C_iols Zn] = CS_IOLS(mtx_A,b,epsilon,nPower,t);     %IOLS algorithm   

    [y_can_IOLS, y_resid_IOLS] = SIcancellation_Nonlinear(x_test,y_test,h_IOLS, ...
                        params.nonorder,chanLen);

    times2 = toc;

    vec_time2 = [vec_time2 times2];
end
%% Calculating Runing Time
mean_times0 = mean(vec_time0)

mean_times1 = mean(vec_time1)

mean_times2 = mean(vec_time2)

