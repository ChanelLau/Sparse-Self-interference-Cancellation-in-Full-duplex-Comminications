function [chan] = SIestimation_Nonlinear(x,y,chanLen,order,alpha) 

%  SIestimation_Nonlinear.
%
%
% Dec 2022.
%
% Info: liuchang@dgut.edu.com
% -------------------------------------------------------------------------
% $Revision: 1.0$  $Date: 2023/01/11$
% $Revision: 1.1$  $Date: xxxx/xx/xx$
% -------------------------------------------------------------------------
% License to use and modify this code is granted freely without warranty to
% all, as long as the original authors are referenced and attributed as such.
% The original authors maintain the right to be solely associated with this
% work.
% -------------------------------------------------------------------------
% ?2022
% Chang Liu,  
% Department of Electronics Engineering
% (DGUT) -- Dongguan University of Tech.

disp('Nonlinear self-interfernece channel estimation:');

nBasisFunctions = ((order+1)/2)*((order+1)/2+1);

mtx_A = zeros((length(x)-chanLen),nBasisFunctions*chanLen);

matInd = 0;

for i = 1:2:order

    for j = 0:i

        fprintf(['Constructing basis functions...' ...
                  '%d/%d\n'],matInd+1,nBasisFunctions);

        xnl = power(x,j).*power(conj(x),(i-j));

        for n = 1: (length(x)-chanLen)

            mtx_A(n, (matInd*chanLen+1):((matInd+1)*chanLen)) = ...
                fliplr(xnl((n+1):(n+chanLen)).');

        end

        matInd = matInd+1;

    end
end

Y0 = y((chanLen+1):end);

chan = pinv(mtx_A) *Y0;

%chan = inv(mtx_A'*mtx_A+alpha*eye(size(mtx_A,2))) * mtx_A' * Y0;

%chan = (mtx_A'*mtx_A+alpha*eye(size(mtx_A,2)))\(mtx_A'*Y0);