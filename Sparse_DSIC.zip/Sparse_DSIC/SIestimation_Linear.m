function [chan] = SIestimation_Linear(x,y,chanLen,alpha) 

% SIestimation_Linear.
%
%
% Dec 2022.
%
% Info: liuchang@dgut.edu.cn
% -------------------------------------------------------------------------
% $Revision: 1.0$  $Date: 2023/01/10$
% $Revision: 1.1$  $Date: xxxx/xx/xx$
% -------------------------------------------------------------------------
% License to use and modify this code is granted freely without warranty to
% all, as long as the original authors are referenced and attributed as such.
% The original authors maintain the right to be solely associated with this
% work.
% -------------------------------------------------------------------------
% ?2022
% Chang Liu,  
% Department of Electronics Engineering
% (DGUT) -- Dongguan University of Tech.

mtx_A = zeros((length(x)-chanLen),chanLen);

for i = 1: (length(x)-chanLen)

     mtx_A(i,:) = fliplr(x((i+1):(i+chanLen)).');

end

Y0 = y((chanLen+1):end);

chan = (mtx_A'*mtx_A+alpha*eye(size(mtx_A,2)))\(mtx_A'*Y0);
