function [x, y, noise,nPower]= Load_data(params) 

% Load_data function.
%
%
% Dec 2022.
%
% Info: liuchang@dgut.edu.cn
% -------------------------------------------------------------------------
% $Revision: 1.0$  $Date: 2023/01/09$
% $Revision: 1.1$  $Date: xxxx/xx/xx$
% -------------------------------------------------------------------------
% License to use and modify this code is granted freely without warranty to
% all, as long as the original authors are referenced and attributed as such.
% The original authors maintain the right to be solely associated with this
% work.
% -------------------------------------------------------------------------
% ?2022
% Chang Liu,  
% Department of Electronics Engineering
% (DGUT) -- Dongguan University of Tech.

load('fdTestbedData20MHz10dBm.mat');

dataOffset = params.dataOffset;

chanLen = params.hSILen;

offset = dataOffset - ceil(chanLen/2);

x = txSamples(1:(end-offset));

y = analogResidual((offset+1):end);

y = y - mean(y);

noise = noiseSamples;

nPower = noisePower;
%nPower = 10^(noisePower/10);