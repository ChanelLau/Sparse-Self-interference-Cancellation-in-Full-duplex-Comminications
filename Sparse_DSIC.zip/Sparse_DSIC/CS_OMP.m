function [chan C0] = CS_OMP(mtx_A,b,t,epsilon,alpha) 

% OMP Algorithm.
%
%
% June 2023.
%
% Info: chaneaaa@163.com
% -------------------------------------------------------------------------
% $Revision: 1.0$  $Date: 2023/07/18$
% $Revision: 1.1$  $Date: xxxx/xx/xx$
% -------------------------------------------------------------------------
% License to use and modify this code is granted freely without warranty to
% all, as long as the original authors are referenced and attributed as such.
% The original authors maintain the right to be solely associated with this
% work.
% -------------------------------------------------------------------------
% ?2023
% Chang Liu,  
% Department of Electronics Engineering
% (DGUT) -- Dongguan University of Tech.

%% CS_OMP algorithm

[b_rows,b_columns] = size(b);

if b_rows < b_columns
   b = b';                       %b should be a column vector
end

[M,N] = size(mtx_A);             %measurement matrix demenaion: M*N 

k = t;                           % preselected sparse level

%% initialization 
r = b;                           

Cn = [];                         

An = [];                         

%% Normalization
abs_colmn = sqrt(sum(abs(mtx_A).^2)); 

abs_matrix = repmat(abs_colmn,M,1);

norm_A  = mtx_A./abs_matrix;

%% OMP迭代求解
ii = 1;
while ii <= k
    product = norm_A' * r;        % inner products
    [val,index] = max(abs(product));
    Cn = [Cn index];
    An = [An mtx_A(:,index)];
%   xk = inv(An' * An) * An' * b;
    xk = pinv(An) * b;
%   xk   = (An'*An+alpha*eye(size(An,2)))\(An'*b);  % LS solution
    r    = b - An * xk; 

    kapa = (norm(r).^2)/(b'*b);

    if kapa  < epsilon   
       break;
    end

    ii = ii +1;
end

x_recovery = zeros(N,1);

x_recovery(Cn) = xk;

C0 = Cn;

chan = x_recovery;               % reconstructed coefficients


