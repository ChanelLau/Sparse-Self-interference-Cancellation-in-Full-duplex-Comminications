% 
% DEMO on test_OMP_IOLS_Nonlinear
% test_OMP_IOLS_Nonlinear for different epsilons with known noise variance.
%
% This demo file implements the experimental test shown in:

% July 2023.
%
% Info: liuchang@dgut.edu.cn
% -------------------------------------------------------------------------
% $Revision: 1.0$  $Date: 2023/08/09$
% $Revision: 1.1$  $Date: xxxx/xx/xx$
% -------------------------------------------------------------------------
% License to use and modify this code is granted freely without warranty to
% all, as long as the original authors are referenced and attributed as such.
% The original authors maintain the right to be solely associated with this
% work.
% -------------------------------------------------------------------------
% ?2022
% Chang Liu,  
% Department of Electronics Engineering
% (DGUT) -- Dongguan University of Tech.
% -------------------------------------------------------------------------

clear; 
close all;
disp('test_OMP_IOLS_Nonlinear for different epsilons with known noise vaeiance');
% -------------------------------------------------------------------------
%%  Data generation
params.samplingFreMHz = 20.48;
params.hSILen = 13;
params.nonorder = 7;
params.dataOffset = 14;
params.trainingRatio = 0.8;

[x, y, noise, nPower]= Load_data(params);
Numtraining = floor(length(x)*params.trainingRatio);
x_training = x(1:Numtraining);
y_training = y(1:Numtraining);
x_test = x((Numtraining+1):end);
y_test = y((Numtraining+1):end);

alpha = 0;                                           %regulerized parameter

%% Memory Polynominal Model generation

[mtx_A, b] = Polymodel_gen(x_training,y_training,params.hSILen, ...
                         params.nonorder);

h_LS = SIestimation_Nonlinear(x,y,params.hSILen,params.nonorder,alpha); 
                                                            %LS algorithm
y_resid_train0 = b - mtx_A * h_LS;

SI_CanLS_train0 = 10*log10(mean(abs(b.^2)) ...
                    /mean(abs(y_resid_train0.^2))); 
                                            %SI suppression ratio(LS training)

PrdBm_train0 = 10*log10(mean(abs(y_resid_train0.^2))) + 30;  
                                                 %residual power(training)

[y_can_test0, y_resid_test0] = SIcancellation_Nonlinear(x_test,y_test,h_LS, ...
                    params.nonorder,params.hSILen);

PydBm = 10*log10(mean(abs(y_test.^2))) + 30;   %LS residual power (testing)

SI_CanLS_test0  = 10*log10(mean(abs(y_test((params.hSILen+1):end).^2)) ...
                             /mean(abs(y_resid_test0.^2)));    
                                          %SI suppression ratio(LS testing)

%% CS_OMP algorithm training
Numeps = 20;

vec_epsilon = linspace(2.5e-5,5e-5,Numeps);

t = 200;  

vec_SIcan_train1 = [];

vec_SIcan_train2 = [];

vec_SIcan_test1 = [];

vec_SIcan_test2 = [];

vec_C_omp = [];

vec_C_ols = [];

vec_PrdBm_train1 = [];

vec_PrdBm_train2 = [];

for i = 1:Numeps
    
    [h_OMP C_omp] = CS_OMP(mtx_A,b,t,vec_epsilon(i),alpha);         
                                                            %OMP algorithm

    [h_IOLS C_iols Zn] = CS_IOLS(mtx_A,b,vec_epsilon(i),nPower,t);  
                                                            %IOLS algorithm

    vec_C_omp = [vec_C_omp length(C_omp)];

    vec_C_ols = [vec_C_ols length(C_iols)];

    y_resid_train1 = b - mtx_A * h_OMP;         %OMP residual SI (training)

    y_resid_train2 = b - mtx_A * h_IOLS;        %IOLS residual SI (training)

    SI_CanOMP_train1 = 10*log10(mean(abs(b.^2))/mean(abs(y_resid_train1.^2))); 
                                        %SI suppression ratio(OMP training)

    PrdBm_train1 = 10*log10(mean(abs(y_resid_train1.^2))) + 30;

    vec_PrdBm_train1 = [vec_PrdBm_train1 PrdBm_train1];

    SI_CanIOLS_train2 = 10*log10(mean(abs(b.^2))/mean(abs(y_resid_train2.^2))); 
                                        %SI suppression ratio(IOLS training)

    PrdBm_train2 = 10*log10(mean(abs(y_resid_train2.^2))) + 30;

    vec_PrdBm_train2 = [vec_PrdBm_train2 PrdBm_train2];

    vec_SIcan_train1 = [vec_SIcan_train1 SI_CanOMP_train1];

    vec_SIcan_train2 = [vec_SIcan_train2 SI_CanIOLS_train2];

%% Testing stage

    [y_can1, y_resid1] = SIcancellation_Nonlinear(x_test,y_test,h_OMP, ...
                         params.nonorder,params.hSILen);

    [y_can2, y_resid2] = SIcancellation_Nonlinear(x_test,y_test,h_IOLS, ...
                        params.nonorder,params.hSILen);

    SI_CanOMP_test1  = 10*log10(mean(abs(y_test((params.hSILen+1):end).^2)) ...
                             /mean(abs(y_resid1.^2)));    
                                        %SI suppression ratio(OMP tseting)

    SI_CanIOLS_test2  = 10*log10(mean(abs(y_test((params.hSILen+1):end).^2)) ...
                             /mean(abs(y_resid2.^2))); 
                                        %SI suppression ratio(IOLS testing)

    vec_SIcan_test1 = [vec_SIcan_test1 SI_CanOMP_test1];

    vec_SIcan_test2 = [vec_SIcan_test2 SI_CanIOLS_test2];

end

vec_SIcan_train0 = zeros(1,length(vec_SIcan_train1));

vec_SIcan_test0 = zeros(1,length(vec_SIcan_test1));

vec_PrdBm_train0 = zeros(1,length(vec_PrdBm_train1));

vec_SIcan_train0(1:end) = SI_CanLS_train0;

vec_SIcan_test0(1:end) = SI_CanLS_test0;

vec_PrdBm_train0(1:end) = PrdBm_train0;

figure(1);
subplot(2,1,1)
plot(vec_epsilon, vec_SIcan_train0,'--xk', 'linewidth',1.5);
hold on;
plot(vec_epsilon, vec_SIcan_train1,'--or', 'linewidth',1.5);
plot(vec_epsilon, vec_SIcan_train2,'--bs', 'linewidth',1.5);
title('(a)')
xlim([2.5e-5,5e-5])
legend('LS','OMP','IOLS')
xlabel('Tolerance for stopping criterion (\epsilon)')
ylabel('SI Cancellation(dB)')
subplot(2,1,2)
plot(vec_epsilon, vec_C_omp,'--or', 'linewidth',1.5);
hold on;
plot(vec_epsilon, vec_C_ols,'--bs', 'linewidth',1.5);
title('(b)')
xlim([2.5e-5,5e-5])
legend('OMP','IOLS')
xlabel('Tolerance for stopping criterion (\epsilon)')
ylabel('Estimated sparse level (K)')
% 
% n_index = 100: 200;
% figure(1); 
% subplot(4,1,1)
% plot(n_index, abs(y_test(100:200)));
% title('(a)')
% xlabel('Sample index')
% ylabel('Amplitude')
% subplot(4,1,2)
% plot(n_index, abs(y_resid_test0(100:200)));
% title('(b)')
% xlabel('Sample index')
% ylabel('Amplitude')
% subplot(4,1,3)
% plot(n_index, abs(y_resid1(100:200)));
% title('(c)')
% xlabel('Sample index')
% ylabel('Amplitude')
% subplot(4,1,4)
% plot(n_index, abs(y_resid2(100:200)));
% title('(d)')
% xlabel('Sample index')
% ylabel('Amplitude')

