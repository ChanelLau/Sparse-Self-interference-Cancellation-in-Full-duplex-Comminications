% 
% DEMO on test_OMP_Nonlinear
% test_OMP_Nonlinear.
%
% This demo file implements the experimental test shown in:

% July 2023.
%
% Info: liuchang@dgut.edu.cn
% -------------------------------------------------------------------------
% $Revision: 1.0$  $Date: 2023/07/18$
% $Revision: 1.1$  $Date: xxxx/xx/xx$
% -------------------------------------------------------------------------
% License to use and modify this code is granted freely without warranty to
% all, as long as the original authors are referenced and attributed as such.
% The original authors maintain the right to be solely associated with this
% work.
% -------------------------------------------------------------------------
% ?2022
% Chang Liu,  
% Department of Electronics Engineering
% (DGUT) -- Dongguan University of Tech.
% -------------------------------------------------------------------------

clear; 
close all;
disp('test OMP and IOLS for sparse SI channel impulse responses ');
% -------------------------------------------------------------------------
%%  Data generation
params.samplingFreMHz = 20.48;
params.hSILen = 13;
params.nonorder = 7;
params.dataOffset = 14;
params.trainingRatio = 0.1;

[x, y, noise, nPower]= Load_data(params);
Numtraining = floor(length(x)*params.trainingRatio);
x_training = x(1:Numtraining);
y_training = y(1:Numtraining);
x_test = x((Numtraining+1):end);
y_test = y((Numtraining+1):end);

mPower = mean(abs(noise.^2));

%% Memory Polynominal Model generation

[mtx_A, b] = Polymodel_gen(x_training,y_training,params.hSILen, ...
                         params.nonorder);

%% CS_OMP algorithm training

alpha = 0;                            %regulerized parameter

epsilon = 3e-5;                       %tolerance for unkonwn noise variance

eta = 1;                               %tolerance for konwn noise variance

t = 80;                               %prespecified Sparse level

h_LS = SIestimation_Nonlinear(x,y,params.hSILen,params.nonorder,alpha); 
                                                         %LS algorithm

[h_OMP C_omp] = CS_OMP(mtx_A,b,t,epsilon,alpha);         %OMP algorithm

[h_IOLS C_iols Zn] = CS_IOLS(mtx_A,b,epsilon,nPower,t);  %IOLS algorithm

[h_IOLS1 C_iols1 Zn1] = CS_IOLS_kapa(mtx_A,b,eta,mPower,t);  %IOLS_kapa algorithm

y_resid_train = b - mtx_A * h_IOLS;                          %residual SI

PresidBm_train = 10*log10(mean(abs(y_resid_train.^2))) + 30  %residual power(dBm)

%% Testing stage

[y_can, y_resid] = SIcancellation_Nonlinear(x_test,y_test,h_IOLS, ...
                    params.nonorder,params.hSILen);

PydBm = 10*log10(mean(abs(y_test.^2))) + 30;           % testing SI power(dBm)

PresidBm_test  = 10*log10(mean(abs(y_resid.^2))) + 30   %residual power(dBm)

load('h_o.mat')

N0 = length(h_LS);
figure(1);
subplot(4,1,1)
stem(abs(h_o));
xlim([0 40+1])
xlabel('Coeff. index')
ylabel('abs(h-Ture)')
title('True coefficients')
subplot(4,1,2)
stem(abs(h_LS)); 
xlim([0 40+1])
xlabel('Coeff. index')
ylabel('abs(h-LS)')
title('LS estimation')
subplot(4,1,3)
stem(abs(h_OMP));
xlim([0 40+1])
xlabel('Coeff. index')
ylabel('abs(h-OMP)')
title('OMP estimation')
subplot(4,1,4)
stem(abs(h_IOLS));
xlim([0 40+1])
xlabel('Coeff. index')
ylabel('abs(h-IOLS)')
title('IOLS estimation')

