function [y_can, y_resid] = SIcancellation_Nonlinear(x,y,chan,order,chanLen) 

% SIcancellation_Nonlinear.
%
%
% Dec 2022.
%
% Info: chaneaaa@163.com
% -------------------------------------------------------------------------
% $Revision: 1.0$  $Date: 2023/01/11$
% $Revision: 1.1$  $Date: xxxx/xx/xx$
% -------------------------------------------------------------------------
% License to use and modify this code is granted freely without warranty to
% all, as long as the original authors are referenced and attributed as such.
% The original authors maintain the right to be solely associated with this
% work.
% -------------------------------------------------------------------------
% ?2022
% Chang Liu,  
% Department of Electronics Engineering
% (DGUT) -- Dongguan University of Tech.

nBasisFunctions = ((order+1)/2)*((order+1)/2+1);

y_can = zeros(length(x)+chanLen-1,1);

% xnl = zeros(length(x),1);

xnl = x;

chanInd = 0;

for i = 1:2:order

    for j = 0:i

        fprintf(['Constructing basis functions and cancellation signal...' ...
                  '%d/%d\n'],chanInd+1,nBasisFunctions);

        xnl = power(x,j).*power(conj(x),(i-j));

        y_can = y_can + conv(xnl, chan(chanInd*chanLen+1:((chanInd+1)*chanLen)));

        chanInd = chanInd+1;

    end
end

y_can = y_can(1:length(x));

y_resid = y((chanLen+1):end) - y_can((chanLen+1):end);